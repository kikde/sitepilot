<?php

return [
    'name' => 'Member',

    'apishot' => [
        'base' => env('APISHOT_BASE', 'https://apishot.kikde.in'),
        'key'  => env('APISHOT_KEY'),
    ],
     'viewbase' => env('VIEW_BASE', 'https://mdmks.kikde.com'),
];
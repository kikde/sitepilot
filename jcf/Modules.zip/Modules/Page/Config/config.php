<?php

return [
    'name' => 'Page'
];

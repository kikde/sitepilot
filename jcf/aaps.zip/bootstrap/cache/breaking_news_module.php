<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BreakingNews\\Providers\\BreakingNewsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BreakingNews\\Providers\\BreakingNewsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
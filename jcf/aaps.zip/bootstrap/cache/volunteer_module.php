<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Volunteer\\Providers\\VolunteerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Volunteer\\Providers\\VolunteerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
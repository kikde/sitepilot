<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Member\\Providers\\MemberServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Member\\Providers\\MemberServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DailyPoster\\Providers\\DailyPosterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DailyPoster\\Providers\\DailyPosterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
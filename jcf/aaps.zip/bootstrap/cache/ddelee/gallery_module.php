<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Gallery\\Providers\\GalleryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Gallery\\Providers\\GalleryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Partner\\Providers\\PartnerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Partner\\Providers\\PartnerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
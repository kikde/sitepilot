<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Birthdays\\Providers\\BirthdaysServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Birthdays\\Providers\\BirthdaysServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
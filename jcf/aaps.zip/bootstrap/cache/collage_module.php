<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Collage\\Providers\\CollageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Collage\\Providers\\CollageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
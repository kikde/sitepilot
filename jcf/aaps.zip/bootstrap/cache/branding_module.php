<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Branding\\Providers\\BrandingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Branding\\Providers\\BrandingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Watermark\\Providers\\WatermarkServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Watermark\\Providers\\WatermarkServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
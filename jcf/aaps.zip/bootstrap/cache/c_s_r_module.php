<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CSR\\Providers\\CSRServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CSR\\Providers\\CSRServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
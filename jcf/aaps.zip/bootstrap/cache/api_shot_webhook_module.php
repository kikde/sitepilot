<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ApiShotWebhook\\Providers\\ApiShotWebhookServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ApiShotWebhook\\Providers\\ApiShotWebhookServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);